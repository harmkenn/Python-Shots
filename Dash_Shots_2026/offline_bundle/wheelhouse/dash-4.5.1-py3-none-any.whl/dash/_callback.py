import collections
import hashlib
import inspect
import logging
import re
import threading
import warnings
from functools import wraps
from typing import Callable, Optional, Any, List, Tuple, Union, Dict, TypeVar, cast

from typing_extensions import ParamSpec

from .dependencies import (
    handle_callback_args,
    handle_grouped_callback_args,
    Output,
    ClientsideFunction,
    Input,
)
from .development.base_component import ComponentRegistry
from .exceptions import (
    InvalidCallbackReturnValue,
    PreventUpdate,
    WildcardInLongCallback,
    MissingLongCallbackManagerError,
    BackgroundCallbackError,
    ImportedInsideCallbackError,
    StreamCallbackError,
)
from ._get_app import get_app
from . import _callback_signing
from ._grouping import (
    flatten_grouping,
    make_grouping_by_index,
    grouping_len,
)
from ._utils import (
    create_callback_id,
    stringify_id,
    to_json,
    coerce_to_list,
    AttributeDict,
    clean_property_name,
)

from .background_callback.managers import BaseBackgroundCallbackManager
from ._callback_context import context_value
from ._streaming import StreamedCallbackResponse
from .types import CallbackExecutionResponse
from ._no_update import NoUpdate
from . import _validate


async def _async_invoke_callback(
    func, *args, **kwargs
):  # used to mark the frame for the debugger
    # Check if the function is a coroutine function
    if inspect.iscoroutinefunction(func):
        return await func(*args, **kwargs)  # %% callback invoked %%
    # If the function is not a coroutine, call it directly
    return func(*args, **kwargs)  # %% callback invoked %%


def _invoke_callback(func, *args, **kwargs):  # used to mark the frame for the debugger
    return func(*args, **kwargs)  # %% callback invoked %%


logger = logging.getLogger(__name__)

GLOBAL_CALLBACK_LIST: List[Any] = []
GLOBAL_CALLBACK_MAP: Dict[str, Any] = {}
GLOBAL_INLINE_SCRIPTS: List[Any] = []
GLOBAL_API_PATHS: Dict[str, Any] = {}


Params = ParamSpec("Params")
ReturnVar = TypeVar("ReturnVar")


# pylint: disable=too-many-locals, too-many-arguments, too-many-positional-arguments
def callback(
    *_args,
    background: bool = False,
    interval: int = 1000,
    progress: Optional[Union[List[Output], Output]] = None,
    progress_default: Any = None,
    running: Optional[List[Tuple[Output, Any, Any]]] = None,
    cancel: Optional[Union[List[Input], Input]] = None,
    manager: Optional[BaseBackgroundCallbackManager] = None,
    cache_args_to_ignore: Optional[list] = None,
    cache_ignore_triggered=True,
    on_error: Optional[Callable[[Exception], Any]] = None,
    api_endpoint: Optional[str] = None,
    optional: Optional[bool] = False,
    hidden: Optional[bool] = None,
    websocket: Optional[bool] = False,
    persistent: Optional[bool] = False,
    mcp_enabled: Optional[bool] = None,
    mcp_expose_docstring: Optional[bool] = None,
    compress_payload: bool = False,
    compress_threshold: int = 5_000,
    **_kwargs,
) -> Callable[[Callable[Params, ReturnVar]], Callable[Params, ReturnVar]]:
    """
    Normally used as a decorator, `@dash.callback` provides a server-side
    callback relating the values of one or more `Output` items to one or
    more `Input` items which will trigger the callback when they change,
    and optionally `State` items which provide additional information but
    do not trigger the callback directly.

    `@dash.callback` is an alternative to `@app.callback` (where `app = dash.Dash()`)
    introduced in Dash 2.0.
    It allows you to register callbacks without defining or importing the `app`
    object. The call signature is identical and it can be used instead of `app.callback`
    in all cases.

    The last, optional argument `prevent_initial_call` causes the callback
    not to fire when its outputs are first added to the page. Defaults to
    `False` and unlike `app.callback` is not configurable at the app level.

    Decorating an async generator function (`async def` with `yield`) registers
    a streaming callback: each yielded value has the same shape as a regular
    return value (one value per `Output`) and is pushed to the browser
    immediately; yield `dash.Patch` objects for incremental updates. Streams
    over the WebSocket callback transport when active, otherwise over the HTTP
    response (NDJSON). Synchronous generators are not supported (they would
    occupy a server worker for the whole stream). Streaming callbacks cannot be
    combined with `background=True`, `mcp_enabled=True` or `api_endpoint`.

    :Keyword Arguments:
        :param background:
            Mark the callback as a background callback to execute in a manager for
            callbacks that take a long time without locking up the Dash app
            or timing out.
        :param manager:
            A background callback manager instance. Currently, an instance of one of
            `DiskcacheManager` or `CeleryManager`.
            Defaults to the `background_callback_manager` instance provided to the
            `dash.Dash constructor`.
            - A diskcache manager (`DiskcacheManager`) that runs callback
              logic in a separate process and stores the results to disk using the
              diskcache library. This is the easiest backend to use for local
              development.
            - A Celery manager (`CeleryManager`) that runs callback logic
              in a celery worker and returns results to the Dash app through a Celery
              broker like RabbitMQ or Redis.
        :param running:
            A list of 3-element tuples. The first element of each tuple should be
            an `Output` dependency object referencing a property of a component in
            the app layout. The second element is the value that the property
            should be set to while the callback is running, and the third element
            is the value the property should be set to when the callback completes.
        :param cancel:
            A list of `Input` dependency objects that reference a property of a
            component in the app's layout.  When the value of this property changes
            while a callback is running, the callback is canceled.
            Note that the value of the property is not significant, any change in
            value will result in the cancellation of the running job (if any).
            This parameter only applies to background callbacks (`background=True`).
        :param progress:
            An `Output` dependency grouping that references properties of
            components in the app's layout. When provided, the decorated function
            will be called with an extra argument as the first argument to the
            function.  This argument, is a function handle that the decorated
            function should call in order to provide updates to the app on its
            current progress. This function accepts a single argument, which
            correspond to the grouping of properties specified in the provided
            `Output` dependency grouping. This parameter only applies to background
            callbacks (`background=True`).
        :param progress_default:
            A grouping of values that should be assigned to the components
            specified by the `progress` argument when the callback is not in
            progress. If `progress_default` is not provided, all the dependency
            properties specified in `progress` will be set to `None` when the
            callback is not running. This parameter only applies to background
            callbacks (`background=True`).
        :param cache_args_to_ignore:
            Arguments to ignore when caching is enabled. If callback is configured
            with keyword arguments (Input/State provided in a dict),
            this should be a list of argument names as strings. Otherwise,
            this should be a list of argument indices as integers.
            This parameter only applies to background callbacks (`background=True`).
        :param cache_ignore_triggered:
            Whether to ignore which inputs triggered the callback when creating
            the cache. This parameter only applies to background callbacks
            (`background=True`).
        :param interval:
            Time to wait between the background callback update requests.
        :param on_error:
            Function to call when the callback raises an exception. Receives the
            exception object as first argument. The callback_context can be used
            to access the original callback inputs, states and output.
        :param optional:
            Mark all dependencies as not required on the initial layout checks.
        :param hidden:
            Hide the callback from the devtools callbacks tab.
        :param api_endpoint:
            If provided, the callback will be available at the given API endpoint.
            This allows you to call the callback directly through HTTP requests
            instead of through the Dash front-end. The endpoint should be a string
            that starts with a forward slash (e.g. `/my_callback`).
            The endpoint is relative to the Dash app's base URL.
            Note that the endpoint will not appear in the list of registered
            callbacks in the Dash devtools.
        :param persistent:
            If True, this callback will not show the "Updating..." title while
            running. Useful for persistent WebSocket callbacks that stay active
            for long periods without requiring a loading indicator.
        :param compress_payload:
            If True, the callback request payload will be compressed using gzip
            compression before being sent to the server. This can significantly
            reduce network transmission size for large payloads.
            Defaults to False.
        :param compress_threshold:
            The size threshold in bytes above which the payload will be compressed
            when `compress_payload` is True. Set to 0 to always compress regardless
            of size. Defaults to 5,000 bytes (5 kB).
    """

    background_spec: Any = None

    config_prevent_initial_callbacks = _kwargs.pop(
        "config_prevent_initial_callbacks", False
    )
    callback_map = _kwargs.pop("callback_map", GLOBAL_CALLBACK_MAP)
    callback_list = _kwargs.pop("callback_list", GLOBAL_CALLBACK_LIST)

    if background:
        background_spec = {
            "interval": interval,
        }

        if manager:
            background_spec["manager"] = manager

        if progress:
            background_spec["progress"] = coerce_to_list(progress)
            validate_background_inputs(background_spec["progress"])

        if progress_default:
            background_spec["progressDefault"] = coerce_to_list(progress_default)

            if not len(background_spec["progress"]) == len(
                background_spec["progressDefault"]
            ):
                raise Exception(
                    "Progress and progress default needs to be of same length"
                )

        if cancel:
            cancel_inputs = coerce_to_list(cancel)
            validate_background_inputs(cancel_inputs)

            background_spec["cancel"] = [c.to_dict() for c in cancel_inputs]
            background_spec["cancel_inputs"] = cancel_inputs

        if cache_args_to_ignore:
            background_spec["cache_args_to_ignore"] = cache_args_to_ignore

        background_spec["cache_ignore_triggered"] = cache_ignore_triggered

    raw = register_callback(
        callback_list,
        callback_map,
        config_prevent_initial_callbacks,
        *_args,
        **_kwargs,
        background=background_spec,
        manager=manager,
        running=running,
        on_error=on_error,
        api_endpoint=api_endpoint,
        optional=optional,
        hidden=hidden,
        websocket=websocket,
        persistent=persistent,
        mcp_enabled=mcp_enabled,
        mcp_expose_docstring=mcp_expose_docstring,
        compress_payload=compress_payload,
        compress_threshold=compress_threshold,
    )

    return cast(
        Callable[[Callable[Params, ReturnVar]], Callable[Params, ReturnVar]], raw
    )


def _validate_stream_callback(callback_id, background, kwargs, is_sync_gen):
    """Reject options a streaming (generator) callback cannot be combined with."""
    if is_sync_gen:
        raise StreamCallbackError(
            f"Streaming callback '{callback_id}' is a synchronous generator, "
            "which is not supported: a sync generator occupies a server worker "
            "for the whole stream. Define it with 'async def' so it streams on "
            "the event loop instead."
        )
    if background is not None:
        raise BackgroundCallbackError(
            f"Streaming callback '{callback_id}' cannot be combined with "
            "background=True: background callbacks return a single result."
        )
    if kwargs.get("mcp_enabled"):
        raise StreamCallbackError(
            f"Streaming callback '{callback_id}' cannot be combined with "
            "mcp_enabled=True: MCP tools expect a single JSON result."
        )
    if kwargs.get("api_endpoint"):
        raise StreamCallbackError(
            f"Streaming callback '{callback_id}' cannot be combined with "
            "api_endpoint: API endpoints expect a single JSON result."
        )


def validate_background_inputs(deps):
    for dep in deps:
        if dep.has_wildcard():
            raise WildcardInLongCallback(
                f"""
                background callbacks does not support dependencies with
                pattern-matching ids
                    Received: {repr(dep)}\n"""
            )


ClientsideFuncType = Union[str, ClientsideFunction]


def clientside_callback(clientside_function: ClientsideFuncType, *args, **kwargs):
    return register_clientside_callback(
        GLOBAL_CALLBACK_LIST,
        GLOBAL_CALLBACK_MAP,
        False,
        GLOBAL_INLINE_SCRIPTS,
        clientside_function,
        *args,
        **kwargs,
    )


# pylint: disable=too-many-arguments, too-many-positional-arguments
def insert_callback(
    callback_list,
    callback_map,
    config_prevent_initial_callbacks,
    output,
    outputs_indices,
    inputs,
    state,
    inputs_state_indices,
    prevent_initial_call,
    background=None,
    manager=None,
    running=None,
    dynamic_creator: Optional[bool] = False,
    no_output=False,
    optional=False,
    hidden=None,
    websocket=False,
    persistent=False,
    mcp_enabled=None,
    mcp_expose_docstring=None,
    compress_payload: bool = False,
    compress_threshold: int = 5_000,
) -> str:
    if prevent_initial_call is None:
        prevent_initial_call = config_prevent_initial_callbacks

    _validate.validate_duplicate_output(
        output, prevent_initial_call, config_prevent_initial_callbacks
    )

    callback_id = create_callback_id(output, inputs, no_output)
    callback_spec = {
        "output": callback_id,
        "inputs": [c.to_dict() for c in inputs],
        "state": [c.to_dict() for c in state],
        "clientside_function": None,
        # prevent_initial_call can be a string "initial_duplicates"
        # which should not prevent the initial call.
        "prevent_initial_call": prevent_initial_call is True,
        "background": background
        and {
            "interval": background["interval"],
        },
        "dynamic_creator": dynamic_creator,
        "no_output": no_output,
        "optional": optional,
        "hidden": hidden,
        "websocket": websocket,
        "persistent": persistent,
        "compress_payload": compress_payload,
        "compress_threshold": compress_threshold,
    }
    # Include output metadata if any output uses partial matching
    output_list = output if isinstance(output, (list, tuple)) else [output]
    if any(getattr(o, "partial_pattern", False) for o in output_list):
        callback_spec["outputs_meta"] = [
            {"partial": True} if getattr(o, "partial_pattern", False) else {}
            for o in output_list
        ]
    if running:
        callback_spec["running"] = running

    callback_map[callback_id] = {
        "inputs": callback_spec["inputs"],
        "state": callback_spec["state"],
        "outputs_indices": outputs_indices,
        "inputs_state_indices": inputs_state_indices,
        "background": background,
        "output": output,
        "raw_inputs": inputs,
        "manager": manager,
        "allow_dynamic_callbacks": dynamic_creator,
        "no_output": no_output,
        "websocket": websocket,
        # Flipped to True by register_callback when the decorated function
        # turns out to be a generator (streaming callback).
        "stream": False,
        "mcp_enabled": mcp_enabled,
        "mcp_expose_docstring": mcp_expose_docstring,
        "compress_payload": compress_payload,
        "compress_threshold": compress_threshold,
    }
    callback_list.append(callback_spec)

    return callback_id


def _set_side_update(ctx, response) -> bool:
    side_update = dict(ctx.updated_props)
    if len(side_update) > 0:
        response["sideUpdate"] = side_update
        return True
    return False


def _initialize_context(args, kwargs, inputs_state_indices, has_output, insert_output):
    """Initialize context and validate output specifications."""
    app = kwargs.pop("app", None)
    output_spec = kwargs.pop("outputs_list")
    callback_ctx = kwargs.pop("callback_context", AttributeDict({"updated_props": {}}))
    context_value.set(callback_ctx)
    original_packages = set(ComponentRegistry.registry)

    if has_output:
        _validate.validate_output_spec(insert_output, output_spec, Output)

    func_args, func_kwargs = _validate.validate_and_group_input_args(
        args, inputs_state_indices
    )
    return (
        output_spec,
        callback_ctx,
        func_args,
        func_kwargs,
        app,
        original_packages,
        False,
    )


def get_request_end_id(secret: bytes):
    """Return the verified end_id for the current request, or ``None``.

    The renderer echoes the server-signed ``endId`` token on every callback
    request; this verifies the signature and returns the underlying end_id so
    background handles can be checked against it.
    """
    return _callback_signing.unsign(
        secret, _callback_signing.END_SCOPE, _request_end_token()
    )


def _request_end_token():
    adapter = get_app().backend.request_adapter()
    return adapter.args.get("endId") if adapter else None


def get_stream_connection_id() -> "str | None":
    """Return the verified streaming connection id for the request, or ``None``.

    The multiplexed streaming transport keys each page's downlink topic on this
    id, so it must be unforgeable: a client that could name an arbitrary topic
    could read another page's stream or inject frames into it. It is derived from
    the server-signed ``end_id`` (the same per-page-load token background-callback
    handles are bound to), never from anything the client picks. A missing or
    forged token yields ``None``, and the backend refuses the request (403).

    ``end_id`` is signed with the server secret, so across worker processes every
    worker must resolve the same secret: set a ``secret_key`` on the server or
    the ``DASH_SECRET_KEY`` environment variable, or cross-worker stream requests
    will not verify. Single-process apps are fine with no configuration.

    The renderer also sends a ``downlinkId`` it picks fresh for each run of
    streams, giving every run its own topic (``<end_id>:<downlinkId>``). A run
    then never resumes a cursor into a topic the store released while the page
    sat idle. It only partitions the page's own space, so it needs no signing.
    """
    end_id = get_request_end_id(_get_signing_secret())
    if end_id is None:
        if _request_end_token():
            _warn_unverified_stream_token()
        return None
    downlink_id = get_app().backend.request_adapter().args.get("downlinkId")
    if not downlink_id:
        return end_id
    if not _DOWNLINK_ID_RE.fullmatch(downlink_id):
        return None
    return f"{end_id}:{downlink_id}"


_DOWNLINK_ID_RE = re.compile(r"[A-Za-z0-9_-]{1,64}")
_stream_token_warning_lock = threading.Lock()
_stream_token_warned = False


def _warn_unverified_stream_token():
    # Once per process: a secret mismatch fails every cross-worker request.
    global _stream_token_warned  # pylint: disable=global-statement
    with _stream_token_warning_lock:
        if _stream_token_warned:
            return
        _stream_token_warned = True
    get_app().logger.warning(
        "A streaming request was refused (403): its stream token failed "
        "verification. On multi-worker or multi-pod deployments this usually "
        "means the workers do not share a signing secret (or the server "
        "restarted since the page loaded); set server.secret_key or the "
        "DASH_SECRET_KEY environment variable."
    )


def _get_signing_secret() -> bytes:
    return get_app()._get_signing_secret()  # pylint: disable=protected-access


def _get_callback_manager(
    kwargs: dict, background: dict
) -> BaseBackgroundCallbackManager:
    """Set up the background callback and manage jobs."""
    callback_manager = background.get(
        "manager", kwargs.get("background_callback_manager", None)
    )
    if background is not None:
        if not callback_manager:
            raise MissingLongCallbackManagerError(
                "Running `background` callbacks requires a manager to be installed.\n"
                "Available managers:\n"
                "- Diskcache (`pip install dash[diskcache]`) to run callbacks in a separate Process"
                " and store results on the local filesystem.\n"
                "- Celery (`pip install dash[celery]`) to run callbacks in a celery worker"
                " and store results on redis.\n"
            )

    adapter = get_app().backend.request_adapter()
    old_job = adapter.args.getlist("oldJob") if hasattr(adapter.args, "getlist") else []

    if old_job:
        secret = _get_signing_secret()
        scope = _callback_signing.job_scope(get_request_end_id(secret))
        for signed_job in old_job:
            # Only terminate jobs whose handle we actually signed for this page
            # load; ignore forged or replayed pids.
            job = _callback_signing.unsign(secret, scope, signed_job)
            if job is not None:
                callback_manager.terminate_job(job)

    return callback_manager


def _setup_background_callback(
    kwargs, background, background_key, func, func_args, func_kwargs, callback_ctx
):
    """Set up the background callback and manage jobs."""
    callback_manager = _get_callback_manager(kwargs, background)
    if not callback_manager:
        return to_json({"error": "No background callback manager configured"})

    try:
        progress_outputs = background.get("progress")

        cache_ignore_triggered = background.get("cache_ignore_triggered", True)

        cache_key = callback_manager.build_cache_key(
            func,
            func_args if func_args else func_kwargs,
            background.get("cache_args_to_ignore", []),
            None
            if cache_ignore_triggered
            else callback_ctx.get("triggered_inputs", []),
            callback_key=background_key,
        )
        job_fn = callback_manager.func_registry.get(background_key)
        ctx_value = AttributeDict(**context_value.get())
        ctx_value.ignore_register_page = True
        ctx_value.pop("background_callback_manager")
        ctx_value.pop("dash_response")

        args_value = ctx_value.get("args")
        if args_value is not None and not isinstance(args_value, dict):
            ctx_value["args"] = dict(args_value)

        job = callback_manager.call_job_fn(
            cache_key,
            job_fn,
            func_args if func_args else func_kwargs,
            ctx_value,
        )

        # Sign the handles before handing them to the browser so they cannot be
        # forged (arbitrary pid kill / arbitrary cache read) or replayed from
        # another page load. The renderer treats them as opaque strings.
        secret = _get_signing_secret()
        end_id = get_request_end_id(secret)
        data = {
            "cacheKey": _callback_signing.sign(
                secret, _callback_signing.cache_scope(end_id), cache_key
            ),
            "job": _callback_signing.sign(
                secret, _callback_signing.job_scope(end_id), str(job)
            ),
        }

        cancel = background.get("cancel")
        if cancel:
            data["cancel"] = cancel

        progress_default = background.get("progressDefault")
        if progress_default:
            data["progressDefault"] = {
                str(o): x for o, x in zip(progress_outputs, progress_default)
            }
        return to_json(data)
    except Exception:  # pylint: disable=broad-exception-caught
        logger.exception("Error setting up background callback")
        return to_json({"error": "Error setting up background callback"})


def _read_request_handles():
    """Read and verify the signed cacheKey/job handles from the current request.

    Returns ``(cache_key, job_id)`` as the raw (unsigned) values, or ``None`` for
    any handle that is missing or whose signature does not verify against this
    page load's end_id. This is what prevents a client from supplying an
    arbitrary cache key (read/delete) or an arbitrary pid (kill).
    """
    adapter = get_app().backend.request_adapter()
    if not adapter:
        return None, None
    secret = _get_signing_secret()
    end_id = get_request_end_id(secret)
    cache_key = _callback_signing.unsign(
        secret,
        _callback_signing.cache_scope(end_id),
        adapter.args.get("cacheKey"),
    )
    job_id = _callback_signing.unsign(
        secret,
        _callback_signing.job_scope(end_id),
        adapter.args.get("job"),
    )
    return cache_key, job_id


def _progress_background_callback(
    response, callback_manager, background, cache_key=None
):
    progress_outputs = background.get("progress")

    if progress_outputs and cache_key is not None:
        # Get the progress before the result as it would be erased after the results.
        progress = callback_manager.get_progress(cache_key)
        if progress:
            response["progress"] = {
                str(x): progress[i] for i, x in enumerate(progress_outputs)
            }


def _update_background_callback(
    error_handler,
    callback_ctx,
    response,
    kwargs,
    background,
    multi,
    output_spec,
    cache_key=None,
    job_id=None,
):
    """Set up the background callback and manage jobs."""
    callback_manager = _get_callback_manager(kwargs, background)

    if cache_key is None or job_id is None:
        req_cache_key, req_job_id = _read_request_handles()
        cache_key = cache_key or req_cache_key
        job_id = job_id or req_job_id

    _progress_background_callback(
        response, callback_manager, background, cache_key=cache_key
    )

    if cache_key is None:
        # No valid handle for this page load -> read nothing, delete nothing.
        output_value = callback_manager.UNDEFINED
    else:
        output_value = callback_manager.get_result(cache_key, job_id)

    return _handle_rest_background_callback(
        output_value,
        callback_manager,
        response,
        error_handler,
        callback_ctx,
        multi,
        output_spec,
        cache_key=cache_key,
        job_id=job_id,
    )


def _handle_rest_background_callback(
    output_value,
    callback_manager,
    response,
    error_handler,
    callback_ctx,
    multi,
    output_spec,
    has_update=False,
    cache_key=None,
    job_id=None,
):
    # Must get job_running after get_result since get_results terminates it.
    job_running = callback_manager.job_running(job_id) if job_id is not None else False
    if not job_running and output_value is callback_manager.UNDEFINED:
        # Job canceled -> no output to close the loop.
        if output_spec:
            output_value = NoUpdate()
        else:
            output_value = None

    elif isinstance(output_value, dict) and "background_callback_error" in output_value:
        error = output_value.get("background_callback_error", {})
        exc = BackgroundCallbackError(
            f"An error occurred inside a background callback: {error['msg']}\n{error['tb']}"
        )
        if error_handler:
            output_value = error_handler(exc)

            if output_value is None and output_spec:
                output_value = NoUpdate()
            # set_props from the error handler uses the original ctx
            # instead of manager.get_updated_props since it runs in the
            # request process.
            has_update = (
                _set_side_update(callback_ctx, response) or output_value is not None
            )
        else:
            raise exc

    if job_running and output_value is not callback_manager.UNDEFINED:
        # cached results.
        callback_manager.terminate_job(job_id)

    if multi and isinstance(output_value, (list, tuple)):
        output_value = [
            NoUpdate() if NoUpdate.is_no_update(r) else r for r in output_value
        ]
    updated_props = callback_manager.get_updated_props(cache_key)
    if len(updated_props) > 0:
        response["sideUpdate"] = updated_props
        has_update = True

    if output_value is callback_manager.UNDEFINED:
        return to_json(response), has_update, True
    return output_value, has_update, False


# pylint: disable=too-many-branches
def _prepare_response(
    output_value,
    output_spec,
    multi,
    response: CallbackExecutionResponse,
    callback_ctx,
    app,
    original_packages,
    background,
    has_update,
    has_output,
    output,
    callback_id,
    allow_dynamic_callbacks,
):
    """Prepare the response object based on the callback output."""
    component_ids: dict = collections.defaultdict(dict)

    if has_output:
        if not multi:
            output_value, output_spec = [output_value], [output_spec]
            flat_output_values = output_value
        else:
            if isinstance(output_value, (list, tuple)):
                # For multi-output, allow top-level collection to be
                # list or tuple
                output_value = list(output_value)
            if NoUpdate.is_no_update(output_value):
                flat_output_values = [output_value]
            else:
                # Flatten grouping and validate grouping structure
                flat_output_values = flatten_grouping(output_value, output)

        if not NoUpdate.is_no_update(output_value):
            _validate.validate_multi_return(
                output_spec, flat_output_values, callback_id
            )

        for val, spec in zip(flat_output_values, output_spec):
            if NoUpdate.is_no_update(val):
                continue
            for vali, speci in (
                zip(val, spec) if isinstance(spec, list) else [[val, spec]]  # type: ignore[reportArgumentType]
            ):
                if not NoUpdate.is_no_update(vali):
                    has_update = True
                    id_str = stringify_id(speci["id"])
                    prop = clean_property_name(speci["property"])
                    component_ids[id_str][prop] = vali

    else:
        if output_value is not None:
            raise InvalidCallbackReturnValue(
                f"No-output callback received return value: {output_value}"
            )

    if not background:
        has_update = _set_side_update(callback_ctx, response) or has_output

    if not has_update:
        raise PreventUpdate

    if len(ComponentRegistry.registry) != len(original_packages):
        diff_packages = list(
            set(ComponentRegistry.registry).difference(original_packages)
        )
        if not allow_dynamic_callbacks:
            raise ImportedInsideCallbackError(
                f"Component librar{'y' if len(diff_packages) == 1 else 'ies'} was imported during callback.\n"
                "You can set `_allow_dynamic_callbacks` to allow for development purpose only."
            )
        dist = app.get_dist(diff_packages)
        response["dist"] = dist
    return response.update({"response": component_ids})


# pylint: disable=too-many-branches,too-many-statements
def register_callback(
    callback_list,
    callback_map,
    config_prevent_initial_callbacks,
    *_args,
    **_kwargs,
):
    (
        output,
        flat_inputs,
        flat_state,
        inputs_state_indices,
        prevent_initial_call,
    ) = handle_grouped_callback_args(_args, _kwargs)
    if isinstance(output, Output):
        # Insert callback with scalar (non-multi) Output
        insert_output = output
        multi = False
        has_output = True
    else:
        # Insert callback as multi Output
        insert_output = flatten_grouping(output)
        multi = True
        has_output = len(output) > 0

    background = _kwargs.get("background")
    manager = _kwargs.get("manager")
    running = _kwargs.get("running")
    on_error = _kwargs.get("on_error")
    if running is not None:
        if not isinstance(running[0], (list, tuple)):
            running = [running]
        running = {
            "running": {str(r[0]): r[1] for r in running},
            "runningOff": {str(r[0]): r[2] for r in running},
        }
    allow_dynamic_callbacks = _kwargs.get("_allow_dynamic_callbacks")

    output_indices = make_grouping_by_index(output, list(range(grouping_len(output))))
    callback_id = insert_callback(
        callback_list,
        callback_map,
        config_prevent_initial_callbacks,
        insert_output,
        output_indices,
        flat_inputs,
        flat_state,
        inputs_state_indices,
        prevent_initial_call,
        background=background,
        manager=manager,
        dynamic_creator=allow_dynamic_callbacks,
        running=running,
        no_output=not has_output,
        optional=_kwargs.get("optional", False),
        hidden=_kwargs.get("hidden", None),
        websocket=_kwargs.get("websocket", False),
        persistent=_kwargs.get("persistent", False),
        mcp_enabled=_kwargs.get("mcp_enabled", None),
        mcp_expose_docstring=_kwargs.get("mcp_expose_docstring"),
        compress_payload=_kwargs.get("compress_payload", False),
        compress_threshold=_kwargs.get("compress_threshold", 5_000),
    )
    # The client-facing spec insert_callback just appended. Streaming is flagged
    # on it below (once the function is known to be a generator) so the renderer
    # can keep streaming callbacks out of its concurrent-request budget.
    client_spec = callback_list[-1]

    # pylint: disable=too-many-locals
    def wrap_func(func):
        # A generator (or async generator) callback streams its yields; that is
        # inferred from the function itself, there is no opt-in keyword.
        is_gen_func = inspect.isgeneratorfunction(func)
        is_async_gen_func = inspect.isasyncgenfunction(func)
        is_stream = is_gen_func or is_async_gen_func
        if is_stream:
            _validate_stream_callback(
                callback_id, background, _kwargs, is_sync_gen=is_gen_func
            )

        if _kwargs.get("api_endpoint"):
            api_endpoint = _kwargs.get("api_endpoint")
            GLOBAL_API_PATHS[api_endpoint] = func

        if background is None:
            background_key = None
        else:
            background_key = BaseBackgroundCallbackManager.register_func(
                func,
                background.get("progress") is not None,
                callback_id,
            )

        @wraps(func)
        def add_context(*args, **kwargs):
            """Handles synchronous callbacks with context management."""
            error_handler = on_error or kwargs.pop("app_on_error", None)

            (
                output_spec,
                callback_ctx,
                func_args,
                func_kwargs,
                app,
                original_packages,
                has_update,
            ) = _initialize_context(
                args, kwargs, inputs_state_indices, has_output, insert_output
            )

            response: CallbackExecutionResponse = {"multi": True}
            jsonResponse: Optional[str] = None
            try:
                if background is not None:
                    adapter = get_app().backend.request_adapter()
                    if not (adapter and adapter.args.get("cacheKey")):
                        return _setup_background_callback(
                            kwargs,
                            background,
                            background_key,
                            func,
                            func_args,
                            func_kwargs,
                            callback_ctx,
                        )

                    output_value, has_update, skip = _update_background_callback(
                        error_handler,
                        callback_ctx,
                        response,
                        kwargs,
                        background,
                        multi,
                        output_spec,
                    )
                    if skip:
                        return output_value
                else:
                    output_value = _invoke_callback(func, *func_args, **func_kwargs)  # type: ignore[reportArgumentType]
            except PreventUpdate:
                if _set_side_update(callback_ctx, response):
                    return to_json(response)
                raise
            except Exception as err:  # pylint: disable=broad-exception-caught
                if error_handler:
                    output_value = error_handler(err)
                    if output_value is None and output_spec:
                        output_value = NoUpdate()
                else:
                    print(err)
                    raise err

            _prepare_response(
                output_value,
                output_spec,
                multi,
                response,
                callback_ctx,
                app,
                original_packages,
                background,
                has_update,
                has_output,
                output,
                callback_id,
                allow_dynamic_callbacks,
            )
            try:
                jsonResponse = to_json(response)
            except TypeError:
                _validate.fail_callback_output(output_value, output)

            return jsonResponse

        @wraps(func)
        async def async_add_context(*args, **kwargs):
            """Handles async callbacks with context management."""
            error_handler = on_error or kwargs.pop("app_on_error", None)

            (
                output_spec,
                callback_ctx,
                func_args,
                func_kwargs,
                app,
                original_packages,
                has_update,
            ) = _initialize_context(
                args, kwargs, inputs_state_indices, has_output, insert_output
            )

            response: CallbackExecutionResponse = {"multi": True}
            jsonResponse: Optional[str] = None

            try:
                if background is not None:
                    adapter = get_app().backend.request_adapter()
                    if not (adapter and adapter.args.get("cacheKey")):
                        return _setup_background_callback(
                            kwargs,
                            background,
                            background_key,
                            func,
                            func_args,
                            func_kwargs,
                            callback_ctx,
                        )
                    output_value, has_update, skip = _update_background_callback(
                        error_handler,
                        callback_ctx,
                        response,
                        kwargs,
                        background,
                        multi,
                        output_spec,
                    )
                    if skip:
                        return output_value
                else:
                    output_value = await _async_invoke_callback(
                        func, *func_args, **func_kwargs
                    )
            except PreventUpdate:
                if _set_side_update(callback_ctx, response):
                    return to_json(response)
                raise
            except Exception as err:  # pylint: disable=broad-exception-caught
                if error_handler:
                    output_value = error_handler(err)
                    if output_value is None and output_spec:
                        output_value = NoUpdate()
                else:
                    raise err

            _prepare_response(
                output_value,
                output_spec,
                multi,
                response,
                callback_ctx,
                app,
                original_packages,
                background,
                has_update,
                has_output,
                output,
                callback_id,
                allow_dynamic_callbacks,
            )
            try:
                jsonResponse = to_json(response)
            except TypeError:
                _validate.fail_callback_output(output_value, output)

            return jsonResponse

        def _build_stream_frame(
            output_value, output_spec, callback_ctx, app, original_packages
        ):
            """Build one stream frame from a yielded value.

            Returns None when the yield produced no update (PreventUpdate or
            all no_update with no set_props).
            """
            response: CallbackExecutionResponse = {"multi": True}
            try:
                _prepare_response(
                    output_value,
                    output_spec,
                    multi,
                    response,
                    callback_ctx,
                    app,
                    original_packages,
                    None,
                    False,
                    has_output,
                    output,
                    callback_id,
                    allow_dynamic_callbacks,
                )
            except PreventUpdate:
                return None
            finally:
                # set_props between yields were folded into this frame's
                # sideUpdate; don't resend them with later frames.
                callback_ctx.updated_props.clear()
            if not response.get("response") and not response.get("sideUpdate"):
                return None
            return response

        def _stream_error_frame(err):
            logger.exception("Exception raised in streamed callback")
            return {"done": True, "error": {"message": str(err) or repr(err)}}

        async def _astream_frames(
            user_gen, error_handler, output_spec, callback_ctx, app, original_packages
        ):
            # Set the callback context var around each resumption of the user
            # generator so dash.ctx/set_props resolve while its body runs. It is
            # set per step rather than once for the whole stream because the
            # keepalive drivers resume each __anext__ in a freshly copied
            # context, where a token taken in an earlier step could not be reset.
            async def _next():
                token = context_value.set(callback_ctx)
                try:
                    return await user_gen.__anext__()
                finally:
                    context_value.reset(token)

            def _handle_error(err):
                # Run the on_error handler under the callback context too so
                # dash.ctx/set_props resolve inside it, matching a step.
                token = context_value.set(callback_ctx)
                try:
                    return error_handler(err)
                finally:
                    context_value.reset(token)

            try:
                while True:
                    frame = None
                    try:
                        output_value = await _next()
                        frame = _build_stream_frame(
                            output_value,
                            output_spec,
                            callback_ctx,
                            app,
                            original_packages,
                        )
                    except (StopAsyncIteration, PreventUpdate):
                        break
                    except Exception as err:  # pylint: disable=broad-exception-caught
                        if error_handler:
                            output_value = _handle_error(err)
                            if output_value is not None:
                                frame = _build_stream_frame(
                                    output_value,
                                    output_spec,
                                    callback_ctx,
                                    app,
                                    original_packages,
                                )
                                if frame is not None:
                                    yield frame
                            break
                        yield _stream_error_frame(err)
                        return
                    if frame is not None:
                        yield frame
                yield {"done": True}
            finally:
                await user_gen.aclose()

        @wraps(func)
        async def async_add_context_stream(*args, **kwargs):
            """Handles streaming callbacks defined as async generators."""
            error_handler = on_error or kwargs.pop("app_on_error", None)

            (
                output_spec,
                callback_ctx,
                func_args,
                func_kwargs,
                app,
                original_packages,
                _,
            ) = _initialize_context(
                args, kwargs, inputs_state_indices, has_output, insert_output
            )

            user_gen = _invoke_callback(func, *func_args, **func_kwargs)
            frames = _astream_frames(
                user_gen,
                error_handler,
                output_spec,
                callback_ctx,
                app,
                original_packages,
            )
            return StreamedCallbackResponse(frames, is_async=True)

        if is_stream:
            # Only async generators reach here; sync generators are rejected in
            # _validate_stream_callback above.
            callback_map[callback_id]["stream"] = True
            # Server-inferred flag (not the removed stream=True keyword): the
            # renderer reads it to exclude long-lived streams from its
            # concurrent-request limit.
            client_spec["stream"] = True
            callback_map[callback_id]["callback"] = async_add_context_stream
        elif inspect.iscoroutinefunction(func):
            callback_map[callback_id]["callback"] = async_add_context
        else:
            # A persistent, no-output callback streams via set_props and typically
            # runs for the life of the connection. When synchronous it occupies a
            # WebSocket worker thread the whole time and can exhaust the pool, so
            # warn that it should be async (async callbacks run on the event loop).
            if _kwargs.get("persistent") and not has_output:
                warnings.warn(
                    f"persistent=True callback '{callback_id}' is synchronous and "
                    "has no Output; it will occupy a WebSocket worker thread for the "
                    "life of the connection and can exhaust the pool. Define it with "
                    "'async def' so it runs on the event loop instead.",
                    RuntimeWarning,
                    stacklevel=2,
                )
            callback_map[callback_id]["callback"] = add_context

        return func

    return wrap_func


_inline_clientside_template = """
(function() {{
    var clientside = window.dash_clientside = window.dash_clientside || {{}};
    var ns = clientside["{namespace}"] = clientside["{namespace}"] || {{}};
    ns["{function_name}"] = {clientside_function};
}})();
"""


def register_clientside_callback(
    callback_list,
    callback_map,
    config_prevent_initial_callbacks,
    inline_scripts,
    clientside_function: ClientsideFuncType,
    *args,
    **kwargs,
):
    output, inputs, state, prevent_initial_call = handle_callback_args(args, kwargs)
    no_output = isinstance(output, (list,)) and len(output) == 0
    insert_callback(
        callback_list,
        callback_map,
        config_prevent_initial_callbacks,
        output,
        None,
        inputs,
        state,
        None,
        prevent_initial_call,
        no_output=no_output,
        hidden=kwargs.get("hidden", None),
    )

    # If JS source is explicitly given, create a namespace and function
    # name, then inject the code.
    if isinstance(clientside_function, str):
        namespace = "_dashprivate_clientside_funcs"
        # Create a hash from the function, it will be the same always
        function_name = hashlib.sha256(clientside_function.encode("utf-8")).hexdigest()

        inline_scripts.append(
            _inline_clientside_template.format(
                namespace=namespace,
                function_name=function_name,
                clientside_function=clientside_function,
            )
        )

    # Callback is stored in an external asset.
    else:
        namespace = clientside_function.namespace
        function_name = clientside_function.function_name

    callback_list[-1]["clientside_function"] = {
        "namespace": namespace,
        "function_name": function_name,
    }
